// Default values
window.DEDUPE_ON_CONTENT = false;
window.DEFAULT_TTL_DAYS = 7;

// Function to update values from storage
function updateConfig() {
  chrome.storage.sync.get(['DEDUPE_ON_CONTENT', 'DEFAULT_TTL_DAYS'], function(items) {
    if (items.DEDUPE_ON_CONTENT !== undefined) window.DEDUPE_ON_CONTENT = items.DEDUPE_ON_CONTENT;
    if (items.DEFAULT_TTL_DAYS !== undefined) window.DEFAULT_TTL_DAYS = items.DEFAULT_TTL_DAYS;
  });
}

// Initial update
updateConfig();

// Listen for changes
chrome.storage.onChanged.addListener(updateConfig);