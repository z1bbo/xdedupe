# XDedupe

Deduplicates your X home timeline by keeping track of what tweets you've seen before.

If an already seen tweet comes up, it will be removed.

more info TODO 
